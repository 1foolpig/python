import os
import cv2
import torch
import numpy as np
import matplotlib.pyplot as plt
from ultralytics import YOLO
import warnings

warnings.filterwarnings('ignore')

# ================= 1. 配置路径与参数 =================
# 模型路径
org_model_path = "F:\\YOLOv8-main\\runs\\SIOU_320_n\\VisDrone_Siou_320_n\\weights\\best.pt"  # 替换为你的原始 YOLOv8 权重文件路径
mod_model_path = "F:\\YOLOv8-main\\runs\\SIOU_320_n\\VisDrone_Siou_320_WTConv_MCA_4detect_distill\\weights\\best.pt"  # 替换为你修改并训练好的权重文件路径

# 图片文件夹与保存路径
img_folder = r"D:\YOLOv8-main\ultralytics\yolo\data\datasets\VisDrone\images\predict"  # 替换为你的测试图片文件夹
output_folder = r"D:\YOLOv8-main\heatmap_comparisons"  # 对比图保存的文件夹

os.makedirs(output_folder, exist_ok=True)

# 提取特征的层索引 (需要根据你的模型结构调整)
# 通常选择主干网络(Backbone)的末尾，或者你加入 HybridAttention/WTConv 的那一层
# 例如：YOLOv8n 的第 9 层是 SPPF，第 8 层是 C2f
TARGET_LAYER_ORG = 8
TARGET_LAYER_MOD = 8

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ================= 2. 定义 Hook 机制 =================
features = {}


def get_feature_hook(name):
    """
    Hook 函数：用于在模型前向传播时拦截并保存指定层的输出
    """

    def hook(model, input, output):
        # 有些层返回的是元组，我们只需要第一个特征张量
        if isinstance(output, (list, tuple)):
            features[name] = output[0].detach()
        else:
            features[name] = output.detach()

    return hook


# ================= 3. 加载模型并注册 Hook =================
print("正在加载模型...")
model_org = YOLO(org_model_path)
model_mod = YOLO(mod_model_path)

# 将模型转移到计算设备并设置为评估模式
model_org_pt = model_org.model.to(device).eval()
model_mod_pt = model_mod.model.to(device).eval()

# 注册 Hook 到指定层
model_org_pt.model[TARGET_LAYER_ORG].register_forward_hook(get_feature_hook('org_features'))
model_mod_pt.model[TARGET_LAYER_MOD].register_forward_hook(get_feature_hook('mod_features'))


# ================= 4. 热力图生成与融合函数 =================
def generate_heatmap_overlay(feature_tensor, original_image):
    """
    将特征张量转换为热力图，并与原图叠加
    """
    if feature_tensor is None:
        return original_image

    # 在通道维度上求均值，将 (1, C, H, W) 压缩为 (H, W)
    heatmap = torch.mean(feature_tensor, dim=1).squeeze().cpu().numpy()

    # 归一化到 0 ~ 1 范围，并去除负值（ReLU的效果）
    heatmap = np.maximum(heatmap, 0)
    max_val = np.max(heatmap)
    if max_val != 0:
        heatmap /= max_val

    # 转换为 0~255 的图像格式
    heatmap = np.uint8(255 * heatmap)

    # 调整热力图大小与原图一致
    img_h, img_w = original_image.shape[:2]
    heatmap_resized = cv2.resize(heatmap, (img_w, img_h))

    # 应用伪彩色 (COLORMAP_JET 会生成红黄蓝渐变的热力图)
    heatmap_color = cv2.applyColorMap(heatmap_resized, cv2.COLORMAP_JET)

    # 将热力图与原图按照一定透明度比例融合 (0.6原图 + 0.4热力图)
    overlay = cv2.addWeighted(original_image, 0.6, heatmap_color, 0.4, 0)
    overlay = cv2.cvtColor(overlay, cv2.COLOR_BGR2RGB)  # 转为 RGB 供 matplotlib 显示

    return overlay


# ================= 5. 批量处理图片 =================
valid_exts = ['.jpg', '.jpeg', '.png', '.bmp']
img_list = [f for f in os.listdir(img_folder) if os.path.splitext(f)[-1].lower() in valid_exts]

print(f"共发现 {len(img_list)} 张图片，开始生成热力图...")

for idx, img_name in enumerate(img_list, 1):
    img_path = os.path.join(img_folder, img_name)

    # 1. 读取原图
    img = cv2.imread(img_path)
    if img is None:
        continue
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    # 2. 图像预处理 (缩放并转换为 Tensor)
    img_tensor = cv2.resize(img, (640, 640))
    img_tensor = img_tensor[:, :, ::-1].transpose(2, 0, 1)  # BGR2RGB, HWC2CHW
    img_tensor = np.ascontiguousarray(img_tensor)
    img_tensor = torch.from_numpy(img_tensor).to(device).float() / 255.0
    img_tensor = img_tensor.unsqueeze(0)  # 添加 Batch 维度

    # 3. 前向传播触发 Hook 提取特征
    with torch.no_grad():
        _ = model_org_pt(img_tensor)
        _ = model_mod_pt(img_tensor)

    # 4. 获取特征图并生成融合热力图
    heatmap_org = generate_heatmap_overlay(features.get('org_features'), img)
    heatmap_mod = generate_heatmap_overlay(features.get('mod_features'), img)

    # 5. 使用 matplotlib 拼接绘图
    fig, axes = plt.subplots(1, 3, figsize=(18, 6))

    axes[0].imshow(img_rgb)
    axes[0].set_title("Original Image", fontsize=14)
    axes[0].axis('off')

    axes[1].imshow(heatmap_org)
    axes[1].set_title("Original YOLOv8 Heatmap", fontsize=14)
    axes[1].axis('off')

    axes[2].imshow(heatmap_mod)
    axes[2].set_title("Modified Model Heatmap", fontsize=14)
    axes[2].axis('off')

    plt.tight_layout()

    # 6. 保存图片并释放内存
    save_path = os.path.join(output_folder, f"heatmap_cmp_{img_name}")
    plt.savefig(save_path, dpi=150, bbox_inches='tight')
    plt.close(fig)  # 极其重要：释放内存，否则批量处理会崩溃

    print(f"[{idx}/{len(img_list)}] 已保存: {save_path}")

print("\n🎉 所有热力图对比图已生成完毕！")